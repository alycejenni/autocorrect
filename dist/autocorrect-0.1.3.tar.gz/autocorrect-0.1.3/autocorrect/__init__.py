from autocorrect.models.coll import Directory
from autocorrect.models.meta import get_config